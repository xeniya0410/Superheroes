package com.example.superheroes

data class Superhero(
    val name: String,
    val description: String,
    val imageResId: Int
)
